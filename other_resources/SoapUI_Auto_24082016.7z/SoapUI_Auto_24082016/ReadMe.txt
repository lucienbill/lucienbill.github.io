/!\ LISEZ-MOI /!\

PROJET = Tests automatis�s de webservices avec SoapUI + Maven
http://intranet.in.ac-orleans-tours.fr/confluence/pages/viewpage.action?pageId=25646983

================================================================================
0: R�sum�
================================================================================

Cet ensemble de fichiers permet de : 

   1) tester un webservice dans SoapUI en chargeant les cas de tests depuis un
      fichier CSV.
   2) IDEM, mais en pilotant SoapUI avec Maven
   3) IDEM, en pilotant avec Jenkins
   4) IDEM, en pilotant avec Squash TA
         -> Attention, le log de Squash TA est inexploitable. Si les tests ne
            d�tectent aucune erreur, c'est bon, mais si une erreur est d�tect�e
            le log de Squash TA ne permettra pas d'en d�terminer la raison. Il
            faudra re-ex�cuter le sc�nario avec la version "desktop" de SoapUI.
   
Pour chaque cas de test, le fichier CSV contient :

   - le nom du cas de test
   - les donn�es � envoyer au webservice
   - les donn�es � v�rifier dans la r�ponse du webservice
   
L'impl�mentation par d�faut peut servir d'exemple et est constitu� de :

   - ./Projet_SoapUI_exemple.xml = projet SoapUI avec le sc�nario de test
   - ./Data/default_data.csv     = jeu de donn�es du sc�nario de test
   - ./pom.xml                   = projet Maven pour ex�cuter le sc�nario de 
                                   test (fonctionne aussi avec Jenkins)
   - ./Squash_TA_pom.xml         = POM d'exemple pour utiliser le projet avec
                                   Squash TA
   - ./maven_settings.xml        = fichier de settings

================================================================================
1: Instructions
================================================================================

--------------------------------------------------------------------------------
1.1: Utiliser la version "dekstop" de SoapUI
--------------------------------------------------------------------------------

Pour utiliser cet outil depuis l'IHM "desktop" de SoapUI d�zippez le, puis : 

   1) Ouvrez SoapUI
   2) Cliquez Sur File > Import Project (Ctrl + I)
   3) Importez "Projet_SoapUI_exemple.xml"
   4) D�roulez "TestSuite", puis ouvrez "TestCase"

L'outil est constitu� des �l�ments suivants :

   - Data_injector : 
        Script groovy permettant de lire le fichier CSV et d'en extraire les 
        donn�es
   - SOAP <nom du cas de test (automatique)> :
        Requ�te SOAP qui prendra automatiquement le nom du cas de test �crit 
        dans le CSV.
        Ouvrez cette requ�te : vous remarquerez des textes du type 
        "${Test_properties#In_token}" : ce sont des marqueurs qui seront 
        remplac�s par les valeurs lues dans le CSV
   - Delay [300] :
        Temps mort de 300 millisecondes, sert � �viter un bug qui emp�che le 
        renommage du cas de test SOAP avec la version "dektop"
   - Test_properties :
        Tableau de propri�t�s (propri�t� = cl� + valeur) contenant les donn�es
        de la ligne du CSV en cours de lecture
   - Looper_properties :
        Propri�t�s li�es aux scripts groovy. Seule les propri�t�s "chemin_CSV"
        et "chemin_CSV_absolu" doivent �tre modifi�es � la main :
          - chemin_CSV_absolu contient le chemin absolu du CSV
          - chemin_CSV contient le chemin relatif du CSV (chemin relatif � l'
            emplacement du projet SoapUI)
          - Si "chemin_CSV_absolu" est renseign�, SoapUI l'utilisera, sinon
            SoapUI utilisera "chemin_CSV"
          - Il est conseill� d'utiliser "chemin_CSV". Le chemin absolu est
            juste n�cessaire pour utiliser avec le projet SoapUI avec Squash TA
   - Looper :
        Script Groovy permettant de faire une boucle "While" (Tant que le 
        fichier contient des lignes, on les traite)

Pour utiliser l'outil avec un autre webservice que celui de l'exemple :

   - Etudiez l'exemple afin de comprendre son fonctionnement, en particulier la
     requ�te SOAP, utile pour comprendre la fa�on dont le ficher CSV est utilis�
     pour injecter des donn�es ET d�finir les donn�es � contr�ler.

   - Cr�ez un fichier CSV contenant vos cas de test (inspir� par la strucutre de
     l'exemple). La premi�re colonne doit s'appeler "Tst_name" et contenir le
     nom des cas de tests.

   - Copiez l'�l�ment "TestSuite de base" vers le projet SoapUI contenant le
     webservice � tester
        Note : donnez un nom coh�rent � la nouvelle TestSuite (exemple :
        "TestSuite avec CSV"), et renommez le TestCase

   - Remplacez l'�tape "Requete � remplacer (Lisez-moi)" par un appel au
     webservice � tester. Attention, la requ�te vers le webservice doit
     obligatoirement �tre en deuxi�me position ! (le script qui modifie
     automatiquement le nom de la requ�te par le nom du cas de test rep�re
     l'�l�ment � modifier gr�ce � sa position)

     Inspirez-vous du TestCase Exemple pour :
       - placer les marqueurs correspondant aux valeurs de votre fichier CSV
         dans le flux � envoyer
       - placer les marqueurs correspondant aux valeurs � contr�ler dans les
         assertions
          Pour voir les assertions, double-cliquez sur une requ�te SOAP ou REST
          contenue dans une TestSuite,
          puis cliquez sur "Assertions (#)" en bas � gauche (# est un nombre
          entier)

--------------------------------------------------------------------------------
1.2: Utiliser le projet Maven (evec Eclipse)
--------------------------------------------------------------------------------

Le projet maven utilise le plugin maven de SoapUI. Note : l'impl�mentation par
d�faut indiqu�e par SmartBear (l'�diteur de SoapUI) est incompl�te, il faut
rajouter des d�pendances pour que le projet fonctionne (le projet de cet exemple
fonctionne).

  1) Avant d'essayer de piloter SoapUI avec Maven, lisez le point 1.1
  2) Utilisez le fichier "maven_settings.xml" afin d'utiliser les bons r�glages
     de maven
  3) Ensuite importez le projet maven (fichier pom.xml), puis lancez le build

Si un test �choue, un ou plusieurs rapports seront g�n�r�s dans ./report, chaque
rapport aura le nom du cas de test en �chec.

Note : avant de piloter le projet avec Maven, assurez-vous que les condtions
suivantes sont vraies pour l'IHM desktop de SoapUI :

   - en cliquant sur le bouton "run TestCase/TestSuite", le sc�nario s'ex�cute
     en entier (et il n'y a � aucun moment besoin d'un action de l'utilisateur
     pour aller jusqu'au bout)
   - les v�rifications automatiques fonctionnent
   - les v�rifications automatiques sont suffisantes (il n'y a pas besoin de
     rev�rifier les flux "� la main")

dans

--------------------------------------------------------------------------------
1.3: Piloter le projet Maven avec Jenkins
--------------------------------------------------------------------------------

La d�marche est similaire au point 1.2 : 
  1) Cr�ez un job Jenkins
  2) Dans le r�pertoire du job (exemple : C:\Program Files (x86)\Jenkins\jobs\?)
     copiez le projet.
  3) Ajoutez un build Maven, indiquez l'emplacement du POM et du fichier de
     SETTINGS ("maven_settings.xml")

Note : la fonctionnalit� de renommage automatique des Test Steps ne fonctionne
pas, mais pour les requ�tes SOAP on peut �crire le nom du cas de test dans un
commentaire XML.

--------------------------------------------------------------------------------
1.4: Piloter le projet SoapUI avec SquashTA
--------------------------------------------------------------------------------

  1) ouvrez le fichier "Squash_TA_pom.xml" : il contient les d�pendances
     n�cessaires
  2) Param�trez le projet SoapUI pourqu'il utilise un chemin absolu pour ouvrir 
     le fichier CSV
  3) Ouvrez "maven_settings.xml" : il contient les plugin_repositories
     n�cessaires
 
Attention : 
  - La fonctionnalit� de renommage automatique des Test Steps ne fonctionne pas
  - Le log est difficile � exploiter : il ne contient que les donn�es retourn�es
    par les webservices.

================================================================================
2: Aller plus loin
================================================================================

--------------------------------------------------------------------------------
2.1: Les assertions
--------------------------------------------------------------------------------

L'exemple utilise des assertions du type "Contains" et "Not Contains" permettant
de v�rifier que la r�ponse du webservice contient/ne contient pas une cha�ne de
caract�res sp�cifique. Il existe d'autres types d'assertions permettant de faire
beaucoup d'autres choses. Exempels : 

   - Xpath et XQuery permettent "d'int�roger" un flux XML
   - SLA permet de v�rifier que le temps de r�ponse du webservice est situ�
     en dessous d'un certain seuil

--------------------------------------------------------------------------------
2.2: Les options
--------------------------------------------------------------------------------

Sur un Test Case (g�n�ralement nomm� "TestCase xxx"), effectuez un clic droit
> Options :

   - la case "Abort on error" a pour effet d'arr�ter l'ex�cution du sc�nario de
     tests en cas d'erreur. On veut g�n�ralement la laisser d�coch�e afin que le
     sc�nario s'ex�cuter jusqu'au bo�t : le log indiquera les cas en erreur.
   - la case "Fail TestCase on error" passe le TestCase au statut "en �chec" si 
     au moins 1 pas de test est en �chec. Cette option est pratique : on laisse
     g�n�ralement cette case coch�e.
   - "Discard OK Results" est utile lorsqu'on se rend compte que la m�moire de
     la machine qui ex�cute les tests est satur�e. Si on a suffisamment
     confiance dans les v�rifications automatiques qui ont �t� mises en place,
     alors il n'est en effet pas n�cessaire de garder les r�sultats des test qui
     s'ex�cutent correctement.

D'autres options sont disponibles, en double cliquant sur le TestCase et en
cliquant sur l'engrennage en bas � gauche: 

   - la case "Errors Only" permet de ne loguer que les erreurs dans le log du
     cas de test, cela facilite la lisibilit�.

En bas de l'�crant SoapUI, on trouve le bouton "script log" : les scripts Groovy
y �crivent des informations. Lorsque tout se passe bien, seule des informations
du type "d�but des tests" / "fin des tests" sont �crites, maislorsque les
scripts groovy rencontrent une erreur (qui n'est pas un bug du webservice, mais
une erreur de param�trage dans SoapUI) certains d�tail utiles peuvent y �tre lus

================================================================================
3: En cas de probl�me
================================================================================

   - Le script log indique "unknown error"
      -> la propri�t� Looper_properties > chemin_CSV n'existe pas, est vide, ou
      fait r�f�rence � un fichier qui n'existe pas
      -> il faut remplacer "/" par "\" dans chemin_CSV
      
   - La requ�te vers le webservice ne change pas automatiquement de nom
      -> V�rifiez que la requ�te SOAP/REST est en deuxi�me position
      -> Augmentez le d�lai de l'�tape "Delay" : il s'agit d'un bug de SoapUI
      qui n'attend pas toujours qu'une instruction soit termin�e avant
      d'ex�cuter la suivante. La valeur de d�lai � partir de laquelle le
      probl�me est r�solu d�pendra de la machine sur laquelle est ex�cut�
      SoapUI.
      
   - Dans les assertions, les "not contains" ne fonctionnent pas toujours.
      -> les contraintes "not contains" servent � v�rifier qu'une cha�ne de
      caract�res n'est pas dans le flux retour d'un webservice. Dans le fichier
      CSV, faites attention � ne jamais laisser ce type de valeur vide, sinon
      SoapUI fera "si le flux contient 'vide' alors il est en erreur". Utilisez
      dans ce cas une valeur qui n'a pas la moindre chance d'�tre dans le flux,
      comme par exemple "Je s'appelle Groot". Dans le script d'exemple, on
      utilise "foobar"
      
   - Les accents dans le fichier CSV ne sont pas interpr�t�s correctement
      -> Encodez le CSV en ANSI (conseil : Utilisez Notepad++ > Encodage >
         Convertir en ANSI)

================================================================================
4: Auteur
================================================================================
Cet outil a �t� cr�� par Lucien BILL sur la base des travaux de Violaine
VARICCA, est gratuit et n'est soumis � aucun droit d'auteur.